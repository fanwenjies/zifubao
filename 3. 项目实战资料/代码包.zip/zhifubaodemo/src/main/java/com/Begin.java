package com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Begin {
    public static void main(String[] args) {
        SpringApplication.run(Begin.class,args);
    }

}
